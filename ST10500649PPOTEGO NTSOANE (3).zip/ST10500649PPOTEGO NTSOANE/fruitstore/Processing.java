
package fruitstore;

public class Processing {
    private String fruit;
    private String weight;
    private int total;
    
    public void Detail()
    {
      
      PrintReceipt data=new PrintReceipt();
      data.setGrandTotalCalculation(total);
      data.Display(fruit, weight, total);
    }
    public void TotalPayment()
    {
//importing inheritance from the Mother class to the child class
         PrintReceipt data=new PrintReceipt();
         data.DisplayingGrand();
    }
    
    public void setFruit(String FruitChoose)
    {
       this.fruit=FruitChoose;
    }
    public String getFruit()
    {
        return this.fruit;
    }
    public void setWeight(String size)
    {
       this.weight=size;
    }
    public String getWeight()
    {
        return this.weight;
    }
     public void setTotal(int total)
    {
       this.total=total;
    }
    public int getTotal()
    {
        return this.total;
    }
    
}
