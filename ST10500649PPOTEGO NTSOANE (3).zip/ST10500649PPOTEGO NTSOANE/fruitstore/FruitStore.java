
package fruitstore;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.InputMismatchException;


public class FruitStore {
    
//Declaring and polulating variables    
    public static int[][] Prices={{3,15,30}
            ,{5,17,32}
            ,{4,16,31}
            ,{8,21,37}};
    public static String[] Fruits={"apple","orange","banana","mango"};
    public static int NumberOfIterms;
    public static int total;
    public static ArrayList<String>FruitName=new ArrayList<>();
    public static ArrayList<String>Weight=new ArrayList<>();
    public static ArrayList<Integer>Total=new ArrayList<>();
            
    public static String found="No";
    public static int TotalIterms;
    public static  String FruitChoose;
    public static String size;
    
    

    public static void main(String[] args) {
//using while loop for consistent display of the menu
try{
    //use Scanner to allow user to input information
      Scanner scanner=new Scanner(System.in);
      Processing data=new Processing();
      
      System.out.println("Please enter customer Name");
            String name=scanner.nextLine();
        while(found.equals("No"))
        {
         
//creating a memu
        System.out.println("****************************************************");
        System.out.println("Fruits Menu");
        System.out.println("****************************************************");
        System.out.println("Fruits         Single         1kg               2kg");
        System.out.println(Fruits[0]+"           R"+Prices[0][0]+"            R"+Prices[0][1]+"                R"+Prices[0][2]);
        System.out.println(Fruits[1]+"          R"+Prices[1][0]+"            R"+Prices[1][1]+"                R"+Prices[1][2]);
        System.out.println(Fruits[2]+"          R"+Prices[2][0]+"            R"+Prices[2][1]+"                R"+Prices[2][2]);
        System.out.println(Fruits[3]+"           R"+Prices[3][0]+"            R"+Prices[3][1]+"                R"+Prices[3][2]);
    
//prompting and allow user to input the number of iterms
            
        System.out.println("how many fruits  would you like to buy "+name+" ?");
        NumberOfIterms=scanner.nextInt();
        
//using the for loop to prompt user and collect their orders
        for(int i=1;i<=NumberOfIterms;i++)
        {
            System.out.println("========================================================================");
            System.out.println("Which fruits would you like to buy?");
            System.out.println("CHOOSE FROM apple,orange,banana or mango");
            scanner.nextLine();
            FruitChoose=scanner.nextLine();
            
            
            System.out.println("Which size of "+FruitChoose+" would you like to buy");
            System.out.println("CHOOSE FROM single,1kg or 2kg");
            size=scanner.nextLine();
             System.out.println("========================================================================");
            
//selecting the correct price for a specific iterm based on the users input
            if(FruitChoose.equals("apple") && size.equals("single"))
            {
                total=Prices[0][0];
                found="Yes";
                 FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
            else  if(FruitChoose.equals("apple") && size.equals("1kg"))
            {
                total=Prices[0][1];
                found="Yes";
                 FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             else  if(FruitChoose.equals("apple") && size.equals("2kg"))
            {
               total=Prices[0][2];
               found="Yes";
                FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             else  if(FruitChoose.equals("orange") && size.equals("single"))
            {
                 total=Prices[1][0];
                 found="Yes";
                  FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             else  if(FruitChoose.equals("orange") && size.equals("1kg"))
            {
                total=Prices[1][1];
                found="Yes";
                 FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             else  if(FruitChoose.equals("orange") && size.equals("2kg"))
            {
                total=Prices[1][2];
                found="Yes";
                 FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             else  if(FruitChoose.equals("banana") && size.equals("single"))
            {
                total=Prices[2][0];
                found="Yes";
                 FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             else  if(FruitChoose.equals("banana") && size.equals("1kg"))
            {
                 total=Prices[2][1];
                 found="Yes";
                 //using arrayList to store information
             FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             else  if(FruitChoose.equals("banana") && size.equals("2kg"))
            {
                 total=Prices[2][2];
                 found="Yes";
                 //using arrayList to store information
             FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
              else  if(FruitChoose.equals("mango") && size.equals("single"))
            {
                total=Prices[3][0];
                found="Yes";
                //using arrayList to store information
             FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             else  if(FruitChoose.equals("mango") && size.equals("1kg"))
            {
                total=Prices[3][1];
                found="Yes";
                //using arrayList to store information
             FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             else  if(FruitChoose.equals("mango") && size.equals("2kg"))
            {
               total=Prices[3][2];
               found="Yes";
               //using arrayList to store information
             FruitName.add(FruitChoose);
             Weight.add(size);
             Total.add(total);
            }
             
            else
             {
                 System.out.println("One of the Fruits was not found.PLEASE TRY AGAIN");
                 found="No";
                 
             }

        }
        
//calculating the number of iterms that are bought by users
        NumberOfIterms=NumberOfIterms+TotalIterms;
        
//using if statement to detemine the correct interms
       if(found.equals("Yes"))
       {
//using a for loop to import the heritance to the mother class(Pocessing) 
           System.out.println("**********************************************");
            System.out.println("Good Fruits Receipt for "+name);
        for(int i=0;i< FruitName.size();i++)
        {
            data.setFruit(FruitName.get(i));
            data.setWeight(Weight.get(i));
            data.setTotal(Total.get(i));
//displaying the required Details
            data.Detail();
            
            
        }
//displaying the total price of all iterms
        data.TotalPayment();
         System.out.println("========================================================================");
//prompting the user 
           System.out.println("Do you want anything as? yes to launch a menu or no to exit");
           String Relaunch=scanner.nextLine();
           
           if(Relaunch.equals("yes"))
           {
               found="No";
               TotalIterms=NumberOfIterms;
           }
           else
           {
               System.out.println("THANK YOU "+name+" for Shopping at Good Fruits"); 
                System.out.println("**********************************************");
           }
           
       }
       else
       {
           System.out.println("ONE OF THE FRUIT YOU ARE LOOKINNG FOR IS NOT OUR MENU");
                
       }
       
        }
    
    }
catch(InputMismatchException e)
{
    
    System.out.println(e.getMessage()+"Error: ");
    System.out.println("Please try again");
}
    }
    
}
