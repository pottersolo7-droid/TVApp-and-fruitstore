
package fruitstore;


public class PrintReceipt extends Processing
{
    public static int GrandTotal;
    public static int PreviousGrandTotal;
    
    
    public void setGrandTotalCalculation(int total)
    {
//calcutating the grand total price of iterm 
        GrandTotal=total+GrandTotal;
    }
    
    public void Display(String fruit,String weight,int total)
    {
//printing the recipe for the user
        System.out.println("**********************************************");
        System.out.println("Name of the fruit: "+fruit);
        System.out.println("Weight: "+weight);
        System.out.println("                            TOTAL: R"+total);
         System.out.println("**********************************************");
        
    }
    public void DisplayingGrand()
    {
//displaying the total for the user
      GrandTotal=GrandTotal-PreviousGrandTotal;
        System.out.println("GRAND TOTAL:  R"+GrandTotal);
        PreviousGrandTotal=GrandTotal;
    }
}
