
package series;
import java.util.Scanner;
import java.util.*;
import java.util.ArrayList;

public class TvApp {
    
//declaration and assignment of variables
    public static String SeriesId;
    public static String SeriesName;
    public static String seriesname;
    public static int SeriesAge;
    public static String SeriesNumberOfEpisodes;
    public static ArrayList<String>Id= new ArrayList<>();
    public static ArrayList<String>Name=new ArrayList<>();
    public static ArrayList<Integer>Age=new ArrayList<>();
    public static ArrayList<String>Episodes=new ArrayList<>();
    public static ArrayList<Integer>NumberOfSeries=new ArrayList<>();
    public static int TotalCounter;
    
    
    
    public static Scanner scanner=new Scanner(System.in);
    
//create a menu and layout in the application
    public static int choose(Scanner scanner)
    {
        System.out.println("============================================================================");
        System.out.println("please select one of one the following menu iterms \n"
                     + "(1) capture new series \n"
                     + "(2) search for a series \n"
                     + "(3) update series age restrictions \n"
                     + "(4) delete a series \n"
                     + "(5) print a series report \n"
                     + "(6) exit application");
         System.out.println("============================================================================");
        return scanner.nextInt();
        
    }
      
    
  //saving and capturing values from the user to memory
   public static void CaptureSeries()
    { 
        System.out.println("CAPTURE A NEW SERIES");
        System.out.println("***********************************");
        System.out.println("please enter series ID");
        SeriesId=scanner.next();
        Id.add(SeriesId);
       
        System.out.println("please enter Series Name");
        
        
        seriesname=scanner.nextLine();
         String name=scanner.nextLine();
        
        Name.add(name);
        
        SeriesAge=0;
        while(SeriesAge<2 || SeriesAge>18)
                {
                    
        System.out.println("please enter Series Age");
        SeriesAge=scanner.nextInt();
        if(SeriesAge<2 || SeriesAge>18)
        {
            System.out.println("You have entered a incorrect series Age!!!");
            System.out.println("Please re-enter the series Age>>");
        }
        
                }
        Age.add(SeriesAge);
        SeriesAge=0;
        
        
        
        System.out.println("Please enter the number of episodes");
        SeriesNumberOfEpisodes=scanner.next();
        Episodes.add(SeriesNumberOfEpisodes);
        
        TotalCounter=TotalCounter+1;
        NumberOfSeries.add(TotalCounter);
        
        System.out.println("Series Processed SuccessFully!!!");
        
        System.out.println("Enter 1 to launch a menu or any number to exit");
        int Menu=scanner.nextInt();
        
        if(Menu==1)
        {
            
        }
        else
        {
            System.exit(0);
        }
    }
   
 //searching for a series and return correct result
    public static void SearchSeries()
    {
        System.out.println("Enter The Series ID to Search");
        String Search=scanner.next();
       
        int i=0;
        String found="NO";
        
        
        for(String x:Id)
        {
            if(Search.equals(x))
            {
                System.out.println("------------------------------------------");
                System.out.println("Series Id: "+Id.get(i)+"\n Series Name: "+Name.get(i)+"\n Series Age Restriction: "+Age.get(i)+"\n Series Number Of Episodes: "+Episodes.get(i));
                System.out.println("------------------------------------------");
                found="YES";
                break;
            }
            i++;
           
        }
        if(found.equals("NO"))
        {
            System.out.println("************************************************");
               System.out.println("The Series with ID: "+Search+" was not found");
               System.out.println("************************************************");
         
        }
         System.out.println("Enter 1 to launch a menu or any number to exit");
             int Menu=scanner.nextInt();
             if(Menu==1)
                  {
                   
                   }
                   else
                   {
                   System.exit(0);
                   }
    }
    
////Updating the series from the memory
    public static void SeriesUpdate()
    {
         System.out.println("Enter The Series ID to Update");
        String Search=scanner.next();
        
        int i=0;
        for(String y:Id)
        {
            if(Search.equals(y))
            {
              Id.remove(i);1
            
              Id.add(Search);
              
        System.out.println("Changing Series Name from "+Name.get(i)+" to:");
        Name.remove(i);
        
        SeriesName=scanner.nextLine();
       String name=scanner.nextLine();
       
      
       
               //deleting  and replacing with new detials
        Name.add(name);
        
        
        SeriesAge=0;
        while(SeriesAge<2 || SeriesAge>18)
                {
                    
        System.out.println("Changing Series Age from "+Age.get(i)+" to:");
        SeriesAge=scanner.nextInt();
        if(SeriesAge<2 || SeriesAge>18)
        {
            System.out.println("You have entered a incorrect series Age!!!");
            System.out.println("Please re-enter the series Age>>");
        }
        
                }
        Age.remove(i);
        Age.add(SeriesAge);          //deleting  and replacing with new detials
        SeriesAge=0;
       
        
        
        System.out.println("Changing the number of episodes from "+Episodes.get(i)+" to:");
        SeriesNumberOfEpisodes=scanner.next();
        Episodes.remove(i);                        //deleting  and replacing with new detials
        Episodes.add(SeriesNumberOfEpisodes);
              break; 
            }
            i++;
        }
        System.out.println("Successfully updated");
        
        System.out.println("Enter 1 to launch a menu or any number to exit");
             int Menu=scanner.nextInt();
             if(Menu==1)
                  {
                   
                   }
                   else
                   {
                       System.out.println("THANK YOU");
                   System.exit(0);
                   }
        
    }
    
//Deletion of series which will remove the values from the memory
    public static void DeleteSeries()
    {
        System.out.println("Enter The Series ID to to DELETE");
        String Search=scanner.next();
        
        System.out.println("Are you sure you want to delete series "+Search+" from the system? yes(y) to delete");
        String yes=scanner.next();
        
        if(yes.equals("y"))
        {
        
        int i=0;
        for(String z:Id) 
        {
            if(Search.equals(z))
            {
                
                System.out.println("Series Id: "+Id.get(i)+" Was Deleted");
                Id.remove(i);
                Name.remove(i);
                Age.remove(i);
                Episodes.remove(i);
                NumberOfSeries.removeLast();
                TotalCounter=TotalCounter-1;
                break;
                
            }
            i++;
        }
         System.out.println("Enter 1 to launch a menu or any number to exit");
        int Menu=scanner.nextInt();
        
        if(Menu==1)
        {
            
        }
        else
        {
            System.exit(0);
        }
        }
        
        
        
        else
        {
            
        }
    }
    
//displaying the series data report
    public static void SeriesReport()
    {
        int i=0;
//using the while loop to display the report according to order
      while(i<=TotalCounter-1) 
      {
          System.out.println("***********************************************");
          System.out.println("Series "+NumberOfSeries.get(i));
          System.out.println("***********************************************");
         System.out.println("Series Id: "+Id.get(i)+"\n Series Name: "+Name.get(i)+"\n Series Age Restriction: "+Age.get(i)+"\n Series Number Of Episodes: "+Episodes.get(i));
     i++;
      }
      System.out.println("***********************************************");
      System.out.println("Enter 1 to launch a menu or any number to exit");
             int Menu=scanner.nextInt();
             if(Menu==1)
                  {
                   
                   }
                   else
                   {
                   System.exit(0);
                   }
    }
//when 6 is entered the application will exit
    public static void ExitSeriesApplications()
    {
                System.out.println("THANK YOU");
        System.exit(0);
    }
    
    public static void main(String[] args) {
       
//prommpting the user to enter 1 to display the menu
    try{
         System.out.println("THE LATEST SERIES - 2025");
          System.out.println("****************************************************");
        System.out.println("Enter 1 to launch a menu or any number to exit");
       int menu=scanner.nextInt();


       if(menu==1)
       {
           int option=0;
//using the while loop for the consistecy of the menu
          while(option <=6)
           {
          option=choose(scanner);
           if(option==1)
           {
             
              CaptureSeries();           //calling the CaptureSeries Method
               
           }
           else if(option==2)            //calling the SearchSeries Method
           {
               SearchSeries();
           }
           else if(option==3)             //calling the Seriesupdate method
           {
              SeriesUpdate();
           }
           else if(option==4)              //calling the DeleteSeries method
           {
               DeleteSeries();             
           }
           else if(option==5)               //calling the SeriesReport method
           {
              SeriesReport();
           }
           else if(option==6)               //calling the ExitSeriesApplication method
           {
                
              
                ExitSeriesApplications();
               System.exit(0);
           }
           else
           {
               System.out.println("invalid option. try again");
           }
        }       
              
            
         
       }
       else
       {
            System.out.println("invalid INPUT. try again");
       }
       
    }
    catch(InputMismatchException e)
    {
        System.out.println("Error: "+e.getMessage());
        System.out.println("please try again");
    }
       
    }
   
}
