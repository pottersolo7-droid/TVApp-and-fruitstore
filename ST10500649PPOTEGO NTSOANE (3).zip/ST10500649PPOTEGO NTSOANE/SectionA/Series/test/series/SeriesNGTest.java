package series;

import static org.testng.Assert.*;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SeriesNGTest {
    
    private Series series;
    
    @BeforeMethod
    public void setUp() {
        series = new Series();
    }

    @Test
    public void testSearchSeries() {
        // Setup
        series.captureSeries("S001", "Test Series", 12, "10");
        
        // Test
        String result = series.searchSeries("S001");
        
        // Verify
        assertNotNull(result);
        assertTrue(result.contains("Test Series"));
        assertTrue(result.contains("12"));
        assertTrue(result.contains("10"));
    }

    @Test
    public void testSearchSeries_SeriesNotFound() {
        // Test
        String result = series.searchSeries("NONEXISTENT");
        
        // Verify
        assertNull(result);
    }

    @Test
    public void testUpdateSeries() {
        // Setup
        series.captureSeries("S001", "Old Name", 12, "10");
        
        // Test
        boolean result = series.updateSeries("S001", "New Name", 14, "15");
        
        // Verify
        assertTrue(result);
        String updatedSeries = series.searchSeries("S001");
        assertTrue(updatedSeries.contains("New Name"));
        assertTrue(updatedSeries.contains("14"));
        assertTrue(updatedSeries.contains("15"));
    }

    @Test
    public void testDeleteSeries() {
        // Setup
        series.captureSeries("S001", "Test Series", 12, "10");
        assertEquals(series.getTotalCounter(), 1);
        
        // Test
        boolean result = series.deleteSeries("S001");
        
        // Verify
        assertTrue(result);
        assertEquals(series.getTotalCounter(), 0);
        assertNull(series.searchSeries("S001"));
    }

    @Test
    public void testDeleteSeries_SeriesNotFound() {
        // Test
        boolean result = series.deleteSeries("NONEXISTENT");
        
        // Verify
        assertFalse(result);
    }

    @Test
    public void testSeriesAgeRestriction_AgeValid() {
        // Test valid ages
        assertTrue(series.validateAgeRestriction(3));
        assertTrue(series.validateAgeRestriction(10));
        assertTrue(series.validateAgeRestriction(17));
    }

    @Test
    public void testSeriesAgeRestriction_SeriesAgeInvalid() {
        // Test invalid ages
        assertFalse(series.validateAgeRestriction(2));
        assertFalse(series.validateAgeRestriction(18));
        assertFalse(series.validateAgeRestriction(0));
        assertFalse(series.validateAgeRestriction(20));
    }

    @Test
    public void testCaptureSeries() {
        // Test
        boolean result = series.captureSeries("S001", "Test Series", 12, "10");
        
        // Verify
        assertTrue(result);
        assertEquals(series.getTotalCounter(), 1);
        assertNotNull(series.searchSeries("S001"));
    }

    @Test
    public void testCaptureSeries_InvalidAge() {
        // Test with invalid age
        boolean result = series.captureSeries("S001", "Test Series", 2, "10");
        
        // Verify
        assertFalse(result);
        assertEquals(series.getTotalCounter(), 0);
    }

    @Test
    public void testGenerateSeriesReport() {
        // Setup
        series.captureSeries("S001", "Series 1", 12, "10");
        series.captureSeries("S002", "Series 2", 14, "20");
        
        // Test
        String report = series.generateSeriesReport();
        
        // Verify
        assertNotNull(report);
        assertTrue(report.contains("Series 1"));
        assertTrue(report.contains("Series 2"));
        assertTrue(report.contains("S001"));
        assertTrue(report.contains("S002"));
    }

    @Test
    public void testGenerateSeriesReport_Empty() {
        // Test
        String report = series.generateSeriesReport();
        
        // Verify
        assertEquals(report, "No series available");
    }
}